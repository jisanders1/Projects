#ifndef clox_compiler_h
#define clox_compiler_h

void compile(const char* sourceCode);

#endif